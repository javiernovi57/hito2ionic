(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-item-detail-item-detail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/item-detail/item-detail.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/item-detail/item-detail.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" size=\"small\" (click)=\"navigateToItemsList()\">\n        <ion-icon name=\"arrow-back\" slot=\"start\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Detalles del producto</ion-title>\n    <ion-buttons slot=\"end\" *ngIf=\"item\">\n        <ion-button fill=\"clear\" size=\"small\" (click)=\"presentActionSheet($event)\">\n          <ion-icon name=\"more\" slot=\"start\"></ion-icon>\n        </ion-button>\n      </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content *ngIf=\"item else loading\">\n  <div class=\"about-header\">\n    <ion-img [src]=\"item.enclosure\" *ngIf=\"item.enclosure else placeholder\"></ion-img>\n  </div>\n  <div class=\"about-info\">\n    <h4 class=\"ion-padding-start\">{{ item.title }}</h4>\n\n    <ion-list>\n      <ion-item>\n        <ion-icon name=\"calendar\" slot=\"start\"></ion-icon>\n        <ion-label>Creado el {{ item.createdAt.seconds*1000 | date: 'medium' }}</ion-label>\n      </ion-item>\n      <ion-item *ngIf=\"item.modifiedAt\">\n        <ion-icon name=\"calendar\" slot=\"start\"></ion-icon>\n        <ion-label>Modificado el {{ item.modifiedAt.seconds*1000 | date: 'medium' }}</ion-label>\n      </ion-item>\n    </ion-list>\n\n    <p class=\"ion-padding-start ion-padding-end\">{{ item.description }}</p>\n  </div>\n</ion-content>\n\n<ng-template #loading>\n  <ion-content>\n    <ion-item>\n      <ion-avatar slot=\"start\">\n        <ion-skeleton-text animated></ion-skeleton-text>\n      </ion-avatar>\n      <ion-label>\n        <h3>\n          <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n        </h3>\n        <p>\n          <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n        </p>\n        <p>\n          <ion-skeleton-text animated style=\"width: 60%\"></ion-skeleton-text>\n        </p>\n      </ion-label>\n    </ion-item>\n  </ion-content>\n</ng-template>\n\n<ng-template #placeholder>\n  <ion-img src=\"https://ionicframework.com/docs/demos/api/card/madison.jpg\"></ion-img>\n</ng-template>");

/***/ }),

/***/ "./src/app/pages/item-detail/item-detail.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/item-detail/item-detail.module.ts ***!
  \*********************************************************/
/*! exports provided: ItemDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemDetailPageModule", function() { return ItemDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _item_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./item-detail.page */ "./src/app/pages/item-detail/item-detail.page.ts");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/shared.module */ "./src/app/shared/shared.module.ts");








const routes = [
    {
        path: '',
        component: _item_detail_page__WEBPACK_IMPORTED_MODULE_6__["ItemDetailPage"]
    }
];
let ItemDetailPageModule = class ItemDetailPageModule {
};
ItemDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"],
        ],
        declarations: [_item_detail_page__WEBPACK_IMPORTED_MODULE_6__["ItemDetailPage"]]
    })
], ItemDetailPageModule);



/***/ }),

/***/ "./src/app/pages/item-detail/item-detail.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/item-detail/item-detail.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2l0ZW0tZGV0YWlsL2l0ZW0tZGV0YWlsLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/pages/item-detail/item-detail.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/item-detail/item-detail.page.ts ***!
  \*******************************************************/
/*! exports provided: ItemDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemDetailPage", function() { return ItemDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _shared_item_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/item.service */ "./src/app/shared/item.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





let ItemDetailPage = class ItemDetailPage {
    constructor(activatedRoute, itemService, alertController, actionSheetController, router) {
        this.activatedRoute = activatedRoute;
        this.itemService = itemService;
        this.alertController = alertController;
        this.actionSheetController = actionSheetController;
        this.router = router;
    }
    ngOnInit() {
        console.log('ItemDetailPage: OnInit');
        this.itemId = this.activatedRoute.snapshot.paramMap.get('id');
        this.sub = this.itemService.getById(this.itemId).subscribe(data => {
            this.item = data;
        });
    }
    ngOnDestroy() {
        console.log('ItemDetailPage: OnDestroy');
        this.sub.unsubscribe();
    }
    presentActionSheet(event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            event.preventDefault();
            event.stopPropagation();
            const actionSheet = yield this.actionSheetController.create({
                header: 'Confirmar',
                buttons: [{
                        text: 'Borrar',
                        role: 'destructive',
                        icon: 'trash',
                        handler: () => {
                            this.deleteItem(this.itemId);
                        }
                    }, {
                        text: 'Actualizar',
                        icon: 'create',
                        handler: () => {
                            this.updateItem(this.itemId);
                        }
                    }, {
                        text: 'Cancelar',
                        icon: 'close',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancelar clickado');
                        }
                    }]
            });
            yield actionSheet.present();
        });
    }
    deleteItem(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: '¿Estás eguro de que quieres borrar esto?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            console.log('Cancelar selección');
                        }
                    }, {
                        text: 'Sí',
                        handler: () => {
                            this.itemService.remove(id);
                            this.navigateToItemsList();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    updateItem(id) {
        this.router.navigate([`/item-edit/${id}`]);
    }
    navigateToItemsList() {
        this.router.navigate(['/item-list']);
    }
};
ItemDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _shared_item_service__WEBPACK_IMPORTED_MODULE_3__["ItemService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
ItemDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-item-detail',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./item-detail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/item-detail/item-detail.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./item-detail.page.scss */ "./src/app/pages/item-detail/item-detail.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _shared_item_service__WEBPACK_IMPORTED_MODULE_3__["ItemService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
], ItemDetailPage);



/***/ })

}]);
//# sourceMappingURL=pages-item-detail-item-detail-module-es2015.js.map