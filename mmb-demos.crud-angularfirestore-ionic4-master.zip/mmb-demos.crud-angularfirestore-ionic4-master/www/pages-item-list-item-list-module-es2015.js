(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-item-list-item-list-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/item-list/item-list.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/item-list/item-list.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Lista de productos</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid fixed>\n    <ion-row>\n      <ion-toolbar *ngIf=\"currentTag let tag\">\n        <ion-chip (click)=\"resetFilters()\">\n          <ion-label>{{ tag.name }}</ion-label>\n          <ion-icon name=\"close-circle\"></ion-icon>\n        </ion-chip>\n      </ion-toolbar>\n    </ion-row>\n    <ion-row *ngIf=\"items$ | async; let items;else loading\">\n      <ion-col size=\"12\" size-md=\"6\" *ngFor=\"let item of items$ | async\">\n        <app-item-headline [item]=\"item\" (action)=\"handleItemAction($event)\" (filter)=\"filterByTag($event)\">\n        </app-item-headline>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <div *ngIf=\"(items$ | async)?.length == 0\" class=\"empty-illustration\">\n    <img src=\"/assets/undraw_empty.svg\"/>\n  </div>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button>\n      <ion-icon name=\"add\" routerLink=\"/item-add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>\n\n<!-- Skeleton screen -->\n<ng-template #loading>\n  <ion-row>\n    <ion-col size=\"12\" size-md=\"6\" *ngFor=\"let number of [0,1,2,3,4]\">\n      <ion-list>\n        <ion-list-header>\n          <ion-skeleton-text animated style=\"width: 20%\"></ion-skeleton-text>\n        </ion-list-header>\n        <ion-item>\n          <ion-avatar slot=\"start\">\n            <ion-skeleton-text animated></ion-skeleton-text>\n          </ion-avatar>\n          <ion-label>\n            <h3>\n              <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n            </h3>\n            <p>\n              <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n            </p>\n            <p>\n              <ion-skeleton-text animated style=\"width: 60%\"></ion-skeleton-text>\n            </p>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n    </ion-col>\n  </ion-row>\n</ng-template>\n<h6>Proyecto en <a href=\"https://github.com/javiernovi57/hitoionic\">Github</a></h6>\n");

/***/ }),

/***/ "./src/app/pages/item-list/item-list.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/item-list/item-list.module.ts ***!
  \*****************************************************/
/*! exports provided: ItemListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemListPageModule", function() { return ItemListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _item_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./item-list.page */ "./src/app/pages/item-list/item-list.page.ts");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/shared.module */ "./src/app/shared/shared.module.ts");








const routes = [
    {
        path: '',
        component: _item_list_page__WEBPACK_IMPORTED_MODULE_6__["ItemListPage"]
    }
];
let ItemListPageModule = class ItemListPageModule {
};
ItemListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"],
        ],
        declarations: [_item_list_page__WEBPACK_IMPORTED_MODULE_6__["ItemListPage"]]
    })
], ItemListPageModule);



/***/ }),

/***/ "./src/app/pages/item-list/item-list.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/pages/item-list/item-list.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".empty-illustration {\n  padding: 50px;\n  min-height: 200px;\n  text-align: center;\n}\n\n.empty-illustration img {\n  max-width: 250px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaXRlbS1saXN0L0M6XFxVc2Vyc1xcSmF2aWVyXFxEZXNrdG9wXFxEQU0gMlxcbW1iLWRlbW9zLmNydWQtYW5ndWxhcmZpcmVzdG9yZS1pb25pYzQtbWFzdGVyL3NyY1xcYXBwXFxwYWdlc1xcaXRlbS1saXN0XFxpdGVtLWxpc3QucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9pdGVtLWxpc3QvaXRlbS1saXN0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtBQ0NGIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaXRlbS1saXN0L2l0ZW0tbGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZW1wdHktaWxsdXN0cmF0aW9uIHtcbiAgcGFkZGluZzogNTBweDtcbiAgbWluLWhlaWdodDogMjAwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmVtcHR5LWlsbHVzdHJhdGlvbiBpbWcge1xuICBtYXgtd2lkdGg6IDI1MHB4O1xufSIsIi5lbXB0eS1pbGx1c3RyYXRpb24ge1xuICBwYWRkaW5nOiA1MHB4O1xuICBtaW4taGVpZ2h0OiAyMDBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uZW1wdHktaWxsdXN0cmF0aW9uIGltZyB7XG4gIG1heC13aWR0aDogMjUwcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/item-list/item-list.page.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/item-list/item-list.page.ts ***!
  \***************************************************/
/*! exports provided: ItemListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemListPage", function() { return ItemListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _shared_item_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/item.service */ "./src/app/shared/item.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





let ItemListPage = class ItemListPage {
    constructor(itemsService, router, alertController) {
        this.itemsService = itemsService;
        this.router = router;
        this.alertController = alertController;
    }
    ngOnInit() {
        this.items$ = this.itemsService.items$;
    }
    handleItemAction(event) {
        const functionName = event.functionName;
        if (this[functionName]) {
            // method exists on the component
            const param = event.functionParam;
            this[functionName](param.item); // call it
        }
    }
    deleteItem(item) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: '¿Estás seguro de que quieres borrar esto?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            console.log('Confirmar Cancelar: ', item.title);
                        }
                    }, {
                        text: 'Sí',
                        handler: () => {
                            this.itemsService.remove(item.id);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    updateItem(item) {
        this.router.navigate([`/item-edit/${item.id}`]);
    }
    filterByTag(tag) {
        console.log('Filtrar por etiqueta: ', tag);
        this.currentTag = tag;
        this.itemsService.filterByTag(tag);
    }
    resetFilters() {
        this.currentTag = null;
        this.itemsService.resetFilters();
    }
};
ItemListPage.ctorParameters = () => [
    { type: _shared_item_service__WEBPACK_IMPORTED_MODULE_3__["ItemService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] }
];
ItemListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-item-list',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./item-list.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/item-list/item-list.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./item-list.page.scss */ "./src/app/pages/item-list/item-list.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_item_service__WEBPACK_IMPORTED_MODULE_3__["ItemService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
], ItemListPage);



/***/ })

}]);
//# sourceMappingURL=pages-item-list-item-list-module-es2015.js.map