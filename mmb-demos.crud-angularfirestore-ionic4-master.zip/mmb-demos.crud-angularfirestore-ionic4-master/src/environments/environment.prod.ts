export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBG1czazuptQrGGLmTWx-c7ZJX-I6m78-c",
	authDomain: "hito2ionic.firebaseapp.com",
	databaseURL: "https://hito2ionic.firebaseio.com",
	projectId: "hito2ionic",
	storageBucket: "hito2ionic.appspot.com",
	messagingSenderId: "647649987107",
	appId: "1:647649987107:web:8486a2a90dcdb4ac68bf96"
  }
};
